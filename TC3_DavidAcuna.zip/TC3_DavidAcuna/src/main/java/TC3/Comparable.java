/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TC3;

/**
 *
 * @author Ana
 * @param <T>
 */
public interface Comparable<T> {
    public int comparableTo(T o);
}
