/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TC3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author Ana
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Triangulo triangulos[]= new Triangulo[4];
        Rectangulo rectangulos[] = new Rectangulo[4];
        Circulo circulos[] = new Circulo[4];
        
        triangulos[0] = new Triangulo(12);
        triangulos[1] = new Triangulo(50);
        triangulos[2] = new Triangulo(16);
        triangulos[3] = new Triangulo(34);
        
        rectangulos[0] = new Rectangulo(12,20);
        rectangulos[1] = new Rectangulo(10, 40);
        rectangulos[2] = new Rectangulo(8, 6);
        rectangulos[3] = new Rectangulo(20, 30);
        
        circulos[0] = new Circulo(12);
        circulos[1] = new Circulo(122);
        circulos[2] = new Circulo(56);
        circulos[3] = new Circulo(96);
        
        System.out.println(circulos[1].comparableTo(triangulos[2]));
    }
    
}
