/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TC3;

/**
 *
 * @author Ana
 */
public class Rectangulo extends Figura implements Comparable<Rectangulo> {

    private double base;
    private double altura;
    private int lados;

    public Rectangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
        this.lados = 4;
    }

    @Override
    public double calcularArea() {
        return base * altura;
    }

    @Override
    public int getLados() {
        return lados;
    }

    @Override
    public int comparableTo(Rectangulo fig) {
        double propio = this.calcularArea();
        double otro = fig.calcularArea();
        if (propio == otro) {
            if (fig.getLados() == 0) {
                System.out.println("Esta figura tiene " + this.lados + " lados y la figura a comparar no tiene ya que es un circulo");
            } else {
                System.out.println("Esta figura tiene " + this.lados + " lados y la figura a comparar tiene " + fig.getLados() + " lados");
            }
            return 0;
        } else if (propio > otro) {
            return 1;
        }
        return -1;
    }
}
