/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TC3;

/**
 *
 * @author Ana
 */
public class Triangulo extends Figura implements Comparable<Figura>{

    private int base;
    private int altura;
    private int lados;

    public Triangulo(int base) {
        this.base = base;
        this.altura = base;
        this.lados = 3;
    }

    @Override
    public int getLados() {
        return lados;
    }

    @Override
    public double calcularArea() {
        return (base * altura) / 2;
    }

    @Override
    public int comparableTo(Figura fig) {
        double propio = this.calcularArea();
        double otro = fig.calcularArea();
        if (propio == otro) {
            if (fig.getLados() == 0) {
                System.out.println("Esta figura tiene " + this.lados + " lados y la figura a comparar no tiene ya que es un circulo");
            } else {
                System.out.println("Esta figura tiene " + this.lados + " lados y la figura a comparar tiene " + fig.getLados() + " lados");
            }
            return 0;
        } else if (propio > otro) {
            return 1;
        }
        return -1;
    }
     

}
