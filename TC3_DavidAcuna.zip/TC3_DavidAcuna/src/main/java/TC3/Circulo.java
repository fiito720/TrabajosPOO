/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TC3;

/**
 *
 * @author Ana
 */
public class Circulo extends Figura implements Comparable<Figura>{
    private int radio;

    public Circulo(int radio) {
        this.radio = radio;
    }

    @Override
    public int getLados() {
        return 0;
    }

    @Override
    public double calcularArea() {
        return radio * radio;
    }
    
    @Override
    public int comparableTo(Figura fig) {
        double propio = this.calcularArea();
        double otro = fig.calcularArea();
        if (propio == otro) {
            if (fig.getLados() == 0) {
                System.out.println("Ninguna de las dos figuras tienen lados ya que ambas son circulos");
            } else {
                System.out.println("Esta figura no tiene lados y la figura a comparar tiene " + fig.getLados() + " lados");
            }
            return 0;
        } else if (propio > otro) {
            return 1;
        }
    

        return -1;
    }
    
}
